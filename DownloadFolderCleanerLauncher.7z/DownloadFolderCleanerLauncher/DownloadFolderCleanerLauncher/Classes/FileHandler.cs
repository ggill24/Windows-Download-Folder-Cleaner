﻿using System;
using System.IO;

namespace DownloadFolderCleanerLauncher.Classes
{
    class FileHandler
    {

        public string DirectoryPath { get; private set; }
        public readonly string textFileName = "date.txt";

        public FileHandler()
        {
            DirectoryPath = Path.Combine(Path.GetTempPath(), "Download Folder Cleaner");

            if (!Directory.Exists(DirectoryPath)) { Directory.CreateDirectory(DirectoryPath); }
        }
        public void CreateDateFile()
        {
            if (!File.Exists(textFileName))
            {
                var fs = File.Create(Path.Combine(DirectoryPath, textFileName));
                fs.Dispose();
            }
        }
        public void WriteDate(DateTime date)
        {
            using (StreamWriter sw = new StreamWriter(Path.Combine(DirectoryPath, textFileName)))
            {
                sw.Write(date);

            }
        }
        public DateTime ReadDate()
        {
            DateTime date = DateTime.UtcNow;

            using (StreamReader sr = new StreamReader(Path.Combine(DirectoryPath, textFileName)))
            {
                var text = sr.ReadLine();

                try
                {
                    date = DateTime.Parse(text);
                }
                catch (InvalidDataException)
                {
                    WriteDate(DateTime.UtcNow);
                }
            }

            return date;
        }
    }
}





                
