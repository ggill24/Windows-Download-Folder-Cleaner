﻿using System;
using System.IO;

namespace DownloadFolderCleanerLauncher.Classes
{
    class FileHandler
    {

        public string DirectoryPath { get; private set; }
        public readonly string textFileName = "date.txt";

        public FileHandler()
        {
            DirectoryPath = Path.Combine(Path.GetTempPath(), "Download Folder Cleaner");

            if (!Directory.Exists(DirectoryPath)) { Directory.CreateDirectory(DirectoryPath); }
        }
        public void CreateDateFile()
        {
            if (!File.Exists(textFileName))
            {
                var fs = File.Create(Path.Combine(DirectoryPath, textFileName));
                fs.Dispose();
            }
        }
        public void WriteDate(DateTime date)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(Path.Combine(DirectoryPath, textFileName)))
                {
                    sw.Write(date);

                }
            }
            catch(Exception ex)
            {
                Program.ShowWindow(Program.GetConsoleWindow(), Program.SW_SHOW);
                Console.WriteLine(ex.Message);
            }
        }
        public DateTime ReadDate()
        {
            DateTime date = DateTime.UtcNow;
            try
            {
                using (StreamReader sr = new StreamReader(Path.Combine(DirectoryPath, textFileName)))
                {
                    var text = sr.ReadLine();

                    date = DateTime.Parse(text);
                }
            }

            catch (InvalidDataException)
            {
                Program.ShowWindow(Program.GetConsoleWindow(), Program.SW_SHOW);
                WriteDate(DateTime.UtcNow);
            }
            catch (Exception ex)
            {
                Program.ShowWindow(Program.GetConsoleWindow(), Program.SW_SHOW);
                Console.WriteLine(ex.Message);
            }

            return date;
        }
    }
}
  





                
