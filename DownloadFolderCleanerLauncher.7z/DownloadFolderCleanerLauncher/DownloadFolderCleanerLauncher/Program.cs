﻿using System;
using DownloadFolderCleanerLauncher.Classes;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace DownloadFolderCleanerLauncher
{
    
    class Program
    {
        /*Credits to: http://stackoverflow.com/questions/3571627/show-hide-the-console-window-of-a-c-sharp-console-application */
        private IntPtr handle = GetConsoleWindow();

        [DllImport("kernel32.dll")]
        public static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        public const int SW_HIDE = 0;
        public const int SW_SHOW = 5;

        static void Main(string[] args)
        {

            ShowWindow(GetConsoleWindow(), SW_HIDE);
            const string cleanerAppPath = @"C:\Users\Gary\PycharmProjects\Windows-Download-Folder-Cleaner\dist\Cleaner\Cleaner";

            FileHandler fileHandler = new FileHandler();

          
            if (File.Exists(Path.Combine(fileHandler.DirectoryPath, fileHandler.textFileName)))
            {
                fileHandler.WriteDate(DateTime.UtcNow);
            }
            else
            {
                fileHandler.CreateDateFile();
                fileHandler.WriteDate(DateTime.UtcNow);
            }

            while (true)
            {
                var currentDate = DateTime.UtcNow;
                var fileDate = fileHandler.ReadDate();

                if(fileDate.Month != currentDate.Month || fileDate.Day - currentDate.Day > 7)
                {
                    try
                    {
                        var processCleaner = Process.GetProcessesByName("Cleaner");
                        
                        //Application is already running
                        if (processCleaner.Length > 0) return;
                        Process.Start(cleanerAppPath);
                    }
                    catch(Exception ex)
                    {
                        ShowWindow(GetConsoleWindow(), SW_SHOW);
                        Console.WriteLine("Unable to start application located at: " + cleanerAppPath);
                        Console.WriteLine("Error: " + ex.Message);
                    }
                    fileHandler.WriteDate(DateTime.UtcNow);
                }

                Thread.Sleep(3600000);
            }
        }
    }
}
      
          
