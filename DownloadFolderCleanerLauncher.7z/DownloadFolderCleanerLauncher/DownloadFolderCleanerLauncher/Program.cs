﻿using System;
using DownloadFolderCleanerLauncher.Classes;
using System.IO;
using System.Threading;
using System.Diagnostics;
namespace DownloadFolderCleanerLauncher
{
    class Program
    {
        static void Main(string[] args)
        {
            const string cleanerAppPath = @"C:\Users\Gary\PycharmProjects\Windows-Download-Folder-Cleaner\dist\Cleaner\Cleaner";

            FileHandler fileHandler = new FileHandler();

          
            if (File.Exists(Path.Combine(fileHandler.DirectoryPath, fileHandler.textFileName)))
            {
                fileHandler.WriteDate(DateTime.UtcNow);
            }
            else
            {
                fileHandler.CreateDateFile();
                fileHandler.WriteDate(DateTime.UtcNow);
            }

            while (true)
            {
                var currentDate = DateTime.UtcNow;
                var fileDate = fileHandler.ReadDate();

                if(fileDate.Month != currentDate.Month || fileDate.Day - currentDate.Day > 7)
                {
                    try
                    {
                        var processCleaner = Process.GetProcessesByName("Cleaner");
                        
                        //Application is already running
                        if (processCleaner.Length > 0) return;
                        Process.Start(cleanerAppPath);
                    }
                    catch(Exception ex)
                    {
                        Console.WriteLine("Unable to start application located at: " + cleanerAppPath);
                        Console.WriteLine("Error: " + ex.Message);
                    }
                    fileHandler.WriteDate(DateTime.UtcNow);
                }

                Thread.Sleep(3600000);
            }
        }
    }
}
      
          
